# IP Networking Notes

- IPv4, IPv6
- Subnetting
- DHCP
- DNS
- NAT
