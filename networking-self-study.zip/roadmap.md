# 📅 Learning Roadmap

- [ ] IP Networking
- [ ] VLAN & Layer 2 Switching
- [ ] Routing (OSPF, Static)
- [ ] DHCP & NAT
- [ ] ACLs & Security
- [ ] Monitoring with Wireshark
- [ ] Network Automation (Python)
