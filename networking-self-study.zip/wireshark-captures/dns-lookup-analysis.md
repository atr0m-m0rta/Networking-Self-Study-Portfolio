# DNS Lookup Analysis

Captured DNS request and response using Wireshark.
