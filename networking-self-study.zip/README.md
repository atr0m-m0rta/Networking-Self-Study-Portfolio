# 🌐 Networking Self-Study Portfolio
This repository tracks my progress as I study core networking concepts using CCNA resources.

I'm documenting hands-on labs, tools, and notes to prepare for a future role in network engineering.
