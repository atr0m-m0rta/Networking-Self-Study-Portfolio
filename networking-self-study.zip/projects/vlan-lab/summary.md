# VLAN Lab Summary

Simulated multiple VLANs across two switches with trunking.
