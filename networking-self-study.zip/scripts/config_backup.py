# Sample Python script for config backup

from netmiko import ConnectHandler

# Add router connection details here
